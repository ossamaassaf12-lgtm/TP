n'importe quelle javascript code
